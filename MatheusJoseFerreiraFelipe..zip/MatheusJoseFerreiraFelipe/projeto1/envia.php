<?php
printf("<pre>");
print_r($_REQUEST);
printf("</pre>");

?>

Matheus José Ferreira Felipe<br>
Estagiário de TI e Estudante<br>
2004-10-19<br>
R. Abraão Aburamja, 279 - JD. Primavera - <br>
<button onclick='history.go(-1)'>voltar</button>